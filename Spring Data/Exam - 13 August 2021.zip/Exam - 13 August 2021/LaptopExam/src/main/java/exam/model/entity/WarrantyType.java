package exam.model.entity;

public enum WarrantyType {
    BASIC, PREMIUM, LIFETIME
}
